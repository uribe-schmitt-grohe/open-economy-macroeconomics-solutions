function [num_table, noutput, nivv, ntby] = edeir_run(param)
%EDEIR_RUN.M
%Compute numerically a first-order approximation, second moments, and impulse responses  implied by  the Small Open Economy Model With An External Debt-Elastic Interest Rate as presented in chapter 4 of ``Open Economy Macroeconomics,'' by Martin Uribe, 2013.

if nargin<1
STD_EPS_A = 0.0129; %standard deviation of innovation to TFP shock
RHO = 0.42; %persistence of TFP shock
PHI = 0.028; %capital adjustment cost
PSSI = 0.11135/150; %debt elasticity of interest rate
else
STD_EPS_A = param(1);
RHO = param(2);
PHI = param(3);
PSSI = param(4);
end

edeir_ss

edeir_num_eval %this .m script was created by running edeir_model.m 


%The linearized equilibrium system is of the form
%y_t=gx x_t
%x_t+1 = hx x_t + ETASHOCK epsilon_t+1
[gx, hx, exitflag] = gx_hx(nfy, nfx, nfyp, nfxp);


nx = size(hx,1); %number of states

%Variance/Covariance matrix of innovation to state vector x_t
varshock = nETASHOCK*nETASHOCK';

%Position of variables in the control vector
noutput = 3; %output
nc = 1; %consumption
nivv = 2; %investment
nh = 4; %hours
ntb = 7; %trade balance
ntby = 8; %trade-balance-to-output ratio
nca = 9; %current account
ncay = 10; %current-account-to-output ratio
%Position of variables in the state vector
nd = 1; %debt
nrb = 2; %Past interest rate (back one period)
nk = 3; %capital
na = 4; %TFP

%standard deviations
 [sigy0,sigx0]=mom(gx,hx,varshock);
stds = sqrt(diag(sigy0));

%correlations with output
corr_xy = sigy0(:,noutput)./stds(noutput)./stds;

%serial correlations
 [sigy1,sigx1]=mom(gx,hx,varshock,1);
scorr = diag(sigy1)./diag(sigy0);

%make a table containing second moments
num_table = [stds*100  scorr corr_xy];

if 1>2

%From this table, select variables of interest (output, c, ivv, h, tby, cay)
disp('In This table:');
disp('Rows: y,c,i,tb/y,ca/y');
disp('Columns: std, corr with y, serial corr.');
num_table1 = num_table([noutput nc nivv ntby  ncay],:);
disp(num_table1);

%LaTex version
clc
disp('\begin{table}');
disp('\onehalfspacing');
disp('\centering');
disp('\caption{Empirical and Theoretical Second Moments\label{table:edeir}}');
disp('%created with c:\uribe\teaching\econ366\lecture_notes\edeir\edeir_run.m');
disp('\medskip');
disp('  ');
disp('\begin{tabular}{|c|c|c|c|c|c|c|}');
disp('\hline\hline');
disp('Variable&\multicolumn{3}{|c|}{Canadian Data}&\multicolumn{3}{|c|}{Model}\\');
disp('\cline{2-7} &$\sigma_{x_t}$ &$\rho_{x_t,x_{t-1}}$ &$\rho_{x_t,GDP_t}$ &$\sigma_{x_t}$  &$\rho_{x_t,x_{t-1}}$ &$\rho_{x_t,GDP_t}$\\ \hline');
disp(['$y$  &  2.81&  0.62& 1 ' tabletex(num_table(noutput,:),2)]);
disp(['$c$&  2.46&   0.70&   0.59  ' tabletex(num_table(nc,:),2)]);
disp(['$i$ &  9.82&  0.31&   0.64   ' tabletex(num_table(nivv,:),2)]);
disp(['$h$&    2.02&  0.54&    0.80   ' tabletex(num_table(nh,:),2)]);
disp(['$\frac{tb}{y}$&  1.87&  0.66&  -0.13  ' tabletex(num_table(ntby,:),2)]);
disp(['$\frac{ca}{y}$&    &     &        ' tabletex(num_table(ncay,:),2)]);
disp('\hline\hline');
disp('\end{tabular}');
disp('\begin{quote}');
disp('Note. Empirical moments are taken from Mendoza (1991). Standard deviations are measured in percentage points.');
disp('\end{quote}');
disp('\end{table}');

%Compute Impulse Responses
T = 11; %number of periods for impulse responses
%Give a unit innovation to TFP
x0 = zeros(nx,1);
x0(end) = 0.01;
%Compute Impulse Response
[IR IRy IRx]=ir(gx,hx,x0,T);

%Plot Impulse responses
t=(0:T-1)';

subplot(3,2,1)
plot(t,IR(:,noutput)*100)
title('Output')

subplot(3,2,2)
plot(t,IR(:,nc)*100)
title('Consumption')

subplot(3,2,3)
plot(t,IR(:,nivv)*100)
title('Investment')

subplot(3,2,4)
plot(t,IR(:,nh)*100)
title('Hours')

subplot(3,2,5)
plot(t,IR(:,ntby)*100)
title('Trade Balance / Output')

subplot(3,2,6)
plot(t,IRx(:,na)*100)
title('TFP Shock')
shg
end
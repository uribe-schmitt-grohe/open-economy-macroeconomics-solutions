%EDEIR_SENSITIVITY.M
%Compute numerically the impulse response to the trade-balance-to-output ratio (tb/ouput) for three parameter configurations:
%baseline
%high PHI (3 times baseline value)
%low RHO (half the baseline value)

clear all

ntby = 9; %trade-balance-to-output ratio

T = 11; %number of periods for impulse responses

%Plot Impulse responses
t=(0:T-1)';

%compute the steady state
edeir_ss

%save the baseline values
PHI0 = PHI;
RHO0 = RHO;

edeir_num_eval %this .m script was created by running edeir_model.m 

%The linearized equilibrium system is of the form
%y_t=gx x_t
%x_t+1 = hx x_t + ETASHOCK epsilon_t+1
[gx, hx, exitflag] = gx_hx(nfy, nfx, nfyp, nfxp);

%Compute Impulse Responses
nx = size(hx,1);

%Give a unit innovation to TFP
x0 = zeros(nx,1);
x0(end) = 0.01;

%Compute Impulse Response
IR=ir(gx,hx,x0,T);

plot(t,IR(:,ntby)*100,'-w','linewidth',4)
hold on

%High PHI
PHI = 3*PHI0;
edeir_num_eval
[gx, hx, exitflag] = gx_hx(nfy, nfx, nfyp, nfxp);
IR=ir(gx,hx,x0,T);
plot(t,IR(:,ntby)*100,'+-w');%,'linewidth',3)
hold on

%LOW RHO
RHO = RHO/2;
PHI = PHI0;
%High PHI
PHI = 3*PHI0;
edeir_num_eval
[gx, hx, exitflag] = gx_hx(nfy, nfx, nfyp, nfxp);
IR=ir(gx,hx,x0,T);
plot(t,IR(:,ntby)*100,'--w','linewidth',4)
xlabel('periods after the productivity shock')
ylabel('percentage points')
legend('baseline','high \phi','low \rho')
hold off

RHO =RHO0;
shg
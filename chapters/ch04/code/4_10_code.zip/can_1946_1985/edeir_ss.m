%edeir_ss.m
%Steady state of the Small Open Economy Model With An External Debt-Elastic Interest Rate as presented in chapter 4 of ``Open Economy Macroeconomics,'' by Martin Uribe, 2013.

%Calibration
%Time unit is a year
SIGG = 2; %mENDOZA
DELTA = 0.1; %depreciation rate
RSTAR = 0.04; %long-run interest rate
ALFA = 0.32; %F(k,h) = k^ALFA h^(1-ALFA)
OMEGA = 1.455; %Frisch ela st. from Mendoza 1991
DBAR =    0.744217657170980; %this value delivers a TB/Y ratio close to 2%. It is not exactly 2 percent. The reason is that it comes from the debt implied by the Mendoza (AER, 1991) calibration (with Uzawa internal preferences). There, Mendoza gives only 2 digirs for the elasticity of the discount factor with respect to 1+c-h^omega/omega, (beta=0.11). This delivers TB/Y close but not exactly equal to 2%. 

%example.m at
%c:\data\uribe\teaching\econ366\wdi

BETTA = 1/(1+RSTAR); %subjective discount factor

 r = RSTAR; %interest rate

KAPA = ((1/BETTA - (1-DELTA)) / ALFA)^(1/(ALFA-1)); %k/h

h = ((1-ALFA)*KAPA^ALFA)^(1/(OMEGA -1)); 

k = KAPA * h; %capital

output = KAPA^ALFA * h; %output

d = DBAR; %debt

c = output-DELTA*k-RSTAR*d;

ivv = DELTA * k; %investment

tb = output - ivv - c; %trade balance

tby = tb/output;

ca = -r*d+tb;

cay = ca/output;

a = 1; %technological factor

tfp = a; %technological factor

la = ((c - h^OMEGA/OMEGA))^(-SIGG); %marginal utility of wealth
%FUNCTION CANUS_RUN.M
function [num_table,num_tableus,stds,scorr,corr_xy,nf,hx,gx] = canus_run(param);

if nargin<1
STD_EPS_A = 2.87;
RHO = 0.56;
PHI = 0.02;
STD_EPS_AUS = 2.87;
RHOUS = 0.56;
PHIUS = 0.02;

param = [STD_EPS_A;RHO;PHI; STD_EPS_AUS;RHOUS;;PHIUS];

end


STD_EPS_A = param(1);
RHO = param(2);
PHI = param(3);
STD_EPS_AUS = param(4);
RHOUS = param(5);
PHIUS = param(6);

%compute steady state
canus_ss;

canus_num_eval;

[gx, hx, exitflag] = gx_hx(nfy, nfx, nfyp, nfxp);

varshock = nETASHOCK*nETASHOCK';

nc = 1;
nivv = 2;
noutput = 3;
nh = 4;
nla = 5;
nq = 6;
ncus = 7;
nivvus = 8;
noutputus = 9;
nhus = 10;
nlaus = 11;
nqus = 12;
ntb = 13;
ntby = 14;


%standard deviations
 [sigy0,sigx0]=mom(gx,hx,varshock);
stds = sqrt(diag(sigy0));

%correlations with output
corr_xy = sigy0(:,noutput)./stds(noutput)./stds;

%serial correlations
 [sigy1,sigx1]=mom(gx,hx,varshock,1);
scorr = diag(sigy1)./diag(sigy0);

num_table_big = [stds corr_xy scorr];

num_table = num_table_big([3 1 2 4 14]*100,:);

num_tableus = num_table_big([9 7 8 10]*100,:);
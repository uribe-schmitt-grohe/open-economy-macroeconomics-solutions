%calibration_continued

clear all
format compact

xx = 1.0001; %scale factor for adjustment of parameters 

%targets
%Canada (Source: Mendoza, AER 1991, table 6, data column)
std_output = 2.81;
std_tby = 1.87;
std_ivv = 9.82;
scorr_output = 0.615;

%calibrated parameters
STD_EPS_A = 0.0129; %standard deviation of innovation to TFP shock
RHO = 0.42; %persistence of TFP shock
PHI = 0.028; %capital adjustment cost
PSSI = 0.11135/150; %debt elasticity of interest rate


param = [STD_EPS_A;RHO;PHI;PSSI];

N = size(param);
target = [std_output;std_ivv;std_tby;scorr_output];

dist = inf;
distnew= dist;
change_dist = 1;
while change_dist~=0;
for n=1:N
for i=[-1 1]
param1 = param;

param1(n) = param1(n)*xx^i;

[num_table,noutput,nivv,ntby] = edeir_run(param1);

progress = [num_table([noutput nivv ntby],1); num_table(noutput,2)];

dist1 = norm((progress./target-1)*100);
if dist1<distnew
distnew=dist1
param = param1;
end
end
end
change_dist = dist-distnew;
dist = distnew;
if rand<0.01
save calibration_continued
end
end
save calibration_continued
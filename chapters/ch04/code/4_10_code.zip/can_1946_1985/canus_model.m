%CANUS_MODEL.M Small Open Economy With An External Debt-Elastic Interest Rate as presented in chapter 4 of ``Open Economy Macroeconomics,'' by Martin Uribe, 2013.
%Run this program only once or every time the structure of the model changes. No need to re run it when parameter values change. 
%model.m computes a symbolic  log-linear approximation to the  function f, which defines  the DSGE model: 
%  E_t f(yp,y,xp,x) =0. 
%here, a p denotes next-period variables.  
%
%Output: Analytical expressions for f and its first derivatives as well as x and y. The output is written to <filename>_num_eval.m which can then be run for numerical evaluations
%
%Calls: anal_deriv.m and anal_deriv_print2f.m 
%
%(c) Stephanie Schmitt-Grohe and Martin Uribe
%
%Date February 2013

filename = 'canus'; %a file with this name and suffix _num_eval.m is created at the end of this program and contains symbolic expression for the function f and its derivatives fx fy fxp fyp 

syms BETTA DELTA ALFA  PHI  RHO  NU STD_EPS_A ETASHOCK SIGG OMEGA 

syms PHIUS  RHOUS STD_EPS_AUS 

syms c cp h hp k kp la lap tb tbp  ivv ivvp tby tbyp a ap output outputp q qp

syms cus cusp hus husp kus kusp laus lausp ivvus ivvusp aus ausp outputus outputusp  qus qusp

%Equilibrium conditions. The symbols e1, e2, ... denote equation 1, equation2, ...


%%%%%%%%%%%%%%%%%%%%%
%UNITED STATES
%%%%%%%%%%%%%%%%%%%%%

%Evolution of debt
e1us = cus + ivvus  - outputus; 

%Output
e2us = -outputus + aus*kus^ALFA*hus^(1-ALFA);

%FOC w.r.t. consumption
e3us = -laus + (cus-hus^OMEGA/OMEGA)^(-SIGG); 

%FOC w.r.t. h
e4us = -hus^(OMEGA-1)+ (1-ALFA) * aus * (kus/hus)^ALFA;

%FOC w.r.t. capital
e5us = -qus *laus + BETTA * lausp * (ALFA * ausp * (kusp/husp)^(ALFA-1) + qusp * ( 1 - DELTA * (1-1/PHIUS) *(ivvusp/DELTA/kusp)^PHIUS- DELTA/PHIUS));

%FOC w.r.t. investment
e6us = -qus +  (ivvus/DELTA/kus)^(1-PHIUS);

%evolution of capital
e7us = -kusp +kus + 1/PHIUS * ((ivvus/DELTA/kus)^PHIUS-1) * DELTA*kus;

%Evolution of TFP
e8us = -log(ausp) + RHOUS * log(aus);

%%%%%%%%%%%%%%%%%%%%%
%CANADA
%%%%%%%%%%%%%%%%%%%%%

%Evolution of debt
e1 = -la + laus; 

%Output
e2 = -output + a*k^ALFA*h^(1-ALFA);

%FOC w.r.t. consumption
e3 = -la + (c-h^OMEGA/OMEGA)^(-SIGG); 

%FOC w.r.t. h
e4 = -h^(OMEGA-1)+ (1-ALFA) * a * (k/h)^ALFA;

%FOC w.r.t. capital
e5 = -la * q + BETTA * lap * (ALFA * ap * (kp/hp)^(ALFA-1) + qp * ( 1 - DELTA * (1-1/PHI) *(ivvp/DELTA/kp)^PHI- DELTA/PHI));

%FOC w.r.t. investment
e6 = -q +  (ivv/DELTA/k)^(1-PHI);

%evolution of capital
e7 = -kp +k+ 1/PHI * ((ivv/DELTA/k)^PHI-1) * DELTA*k;

%Trade balance
e8 = -tb + output-c - ivv;

%Trade-balance-to-output ratio
e9 = -tby + tb/output;

%Evolution of TFP
e10 = -log(ap) + RHO * log(a);

%Create function f
f = eval(eval([e1;e2;e3;e4;e5;e6;e7;e8;e9;e10;e1us;e2us;e3us;e4us;e5us;e6us;e7us;e8us]));

% Define the vector of controls in periods t and t+1, controlvar and controlvarp, and the vector of states in periods t and t+1, statevar and statevarp

%States to substitute from levels to logs

states_in_logs = [kus k aus a];
states_in_logsp = [kusp kp ausp ap];

statevar = [states_in_logs];

statevarp = [states_in_logsp];
 
controls_in_logs = [c ivv output h la q cus  ivvus outputus hus laus qus];

controls_in_logsp = [cp ivvp outputp hp lap qp cusp  ivvusp outputusp husp lausp qusp];

controlvar = [controls_in_logs tb tby]; 

controlvarp = [controls_in_logsp tbp tbyp ]; 

%Number of states
ns = length(statevar);

%Make f a function of the logarithm of the state and control vector

%variables to substitute from levels to logs
variables_in_logs = transpose([states_in_logs, controls_in_logs, states_in_logsp, controls_in_logsp]);

f = subs(f, variables_in_logs, exp(variables_in_logs));

approx = 1;

%Compute analytical derivatives of f
[fx,fxp,fy,fyp]=anal_deriv(f,statevar,controlvar,statevarp,controlvarp,approx);

%Make f and its derivatives a function of the level of its arguments rather than the log
f = subs(f, variables_in_logs, log(variables_in_logs));
fx = subs(fx, variables_in_logs, log(variables_in_logs));
fy = subs(fy, variables_in_logs, log(variables_in_logs));
fxp = subs(fxp, variables_in_logs, log(variables_in_logs));
fyp = subs(fyp, variables_in_logs, log(variables_in_logs));

%Symbolically evaluate f and its derivatives at the nonstochastic steady state (c=cp, etc.)
cu = transpose([statevar controlvar ]);
cup = transpose([statevarp controlvarp  ]);


for subcb=1:2 %substitution must be run twice  in case the original system is a stochastic difference equation of order higher than one. For example, the current model features k_t, k_t+1, and k_t+2 and thus is a 2nd order difference equation

f = subs(f, cup,cu,0);
fx = subs(fx, cup,cu,0);
fy = subs(fy, cup,cu,0);
fxp = subs(fxp, cup,cu,0);
fyp = subs(fyp, cup,cu,0);
end


%Construct ETASHOCK matrix, which determines the var/cov of the forcing term of the system. Specifically, the state vector evolves over time according to 
%x_t+1 = hx x_t + ETASHOCK epsilon_t+1
%the first element of epsilon_t is epsilon^Can_t and the second is epsilon^US_t
%recall: the penultimate element of x_t, is aus and the last is a
ETASHOCK(ns,1) = STD_EPS_A;
ETASHOCK(ns,2) = NU;
ETASHOCK(ns-1,2) = STD_EPS_AUS;


ETASHOCK(1,1) = 0;

varshock = ETASHOCK*ETASHOCK';

%Print derivatives to file <filename>_num_eval.m'  for model evaluation
anal_deriv_print2f(filename,fx,fxp,fy,fyp,f,ETASHOCK);


eval(['save ' filename '.mat'])
%canus_ss.m
%Steady state of the Small Open Economy Model With An External Debt-Elastic Interest Rate as presented in chapter 4 of ``Open Economy Macroeconomics,'' by Martin Uribe, 2013.

%Calibration
%Time unit is a year
NU = 0; %Loading of US productivity innovaiton on Canada productivity innovation
SIGG = 2; %mENDOZA
DELTA = 0.1; %depreciation rate
BETTA = 1/1.04; %subjective discount factor
ALFA = 0.32; %F(k,h) = k^ALFA h^(1-ALFA)
OMEGA = 1.455; %Frisch ela st. from Mendoza 1991

KAPA = ((1/BETTA - (1-DELTA)) / ALFA)^(1/(ALFA-1)); %k/h

hus = ((1-ALFA)*KAPA^ALFA)^(1/(OMEGA -1)); 

kus = KAPA * hus; %capital

outputus = KAPA^ALFA * hus; %output

ivvus = DELTA * kus; %investment

cus = outputus - ivvus; %consumption

laus = ((cus - hus^OMEGA/OMEGA))^(-SIGG); %marginal utility of wealth

qus = 1; %Tobin's q

h = hus;
k = kus;
output = outputus;
c = cus;
ivv = ivvus;
tb = output - ivv - c; %trade balance
tby = tb/output;
aus = 1; %technological factor
a = aus; 
la = laus; 
q = qus;
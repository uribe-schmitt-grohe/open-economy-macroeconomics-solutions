%Get empirical second moments from WDI data (annual 1960-2001);
%
%Go to WDI directory
cd c:\data\uribe\teaching\econ366\wdi

scv = 2; %This is an input of data_preparation.m. It chooses the set of variables for which we require jointly a minimum of years (default 30 years) of consecutive data. A value scv different from one uses the set of variables [y c g i x m]. A value of scv of 1 adds to this set the variable ca.


%the following 2 commands make sure that the detrended method is not hp filtering (see bc_analysis.m)
HP = 0; 
dohp = 0; 
%the detrending method is istead quadratic detrending, i.e., the trend is a polynomial of  order 2 (see the setting of the variable 'orden' in bc_analysis.m)
bc_analysis

%Come back to hwk5_2013 directory
cd c:\data\uribe\teaching\econ366\hwk5_2013

countryname = 'Canada';
%countryname = 'Mexico';
%countryname = 'Argentina';
%countryname = 'Germany';

ncan = find(strcmp(country,countryname));

%Standard Deviations
stds = SD([ngdp nc ni ntby],ncan);

%Serial correlations
scorr = RHOXX([ngdp nc ni ntby],ncan);

%correlations with output
corr_xy = RHOXY([ngdp nc ni ntby],ncan);

%make a table containing second moments
num_table = [stds*100  scorr corr_xy];

clc

disp('In This table:');
disp('Rows: y,c,i,tb/y');
disp('Columns: std,  serial corr, corr with output.');
disp(num_table);

%LaTex version
clc
disp('\begin{center}');
disp('%created with c:\uribe\teaching\econ366\lhwk5_2013\produce_data.m');
disp('\medskip');
disp('  ');
disp('\begin{tabular}{c|c|c|c}');
disp('\hline\hline');
disp('Variable&\multicolumn{3}{|c|}{Canadian Data 1960-2011}\\');
disp('\cline{2-4} &$\sigma_{x_t}$ &$\rho_{x_t,x_{t-1}}$ &$\rho_{x_t,GDP_t}$ \\ \hline');
disp(['$y$ ' tabletex(num_table(1,:),2)]);
disp(['$c$ ' tabletex(num_table(2,:),2)]);
disp(['$i$ ' tabletex(num_table(3,:),2)]);
disp(['$tb/y$ ' tabletex(num_table(4,:),2)]);
disp('\hline\hline');
disp('\end{tabular}');
disp('\begin{quote}');
disp('Note. The data source is World Development Indicators. The series $y$, $c$, and $i$ are in logs, and the series $tb/y$ is in levels. All series were quadratically detrended. Standard deviations are measured in percentage points.');
disp('\end{quote}');
disp('\end{center}');



cd c:\data\uribe\teaching\econ366\hwk5_2013
%cam_num_eval.m was created by running  /Users/niyuanhuang/Documents/MATLAB/reexercise4_5/cam_model.m
nfx = [
[ 0,                                         0,                        0,    x]
[ 0,        ALFA*a*h^(1 - ALFA)*k*k^(ALFA - 1),    a*h^(1 - ALFA)*k^ALFA,    0]
[ 0,                                         0,                        0,    0]
[ 0, -(ALFA*a*k*(k/h)^(ALFA - 1)*(ALFA - 1))/h, -a*(k/h)^ALFA*(ALFA - 1),    0]
[ 0,                                         0,                        0,    0]
[ 0,                                  PHI*k*la,                        0,    0]
[ 0,                                         0,                        0,    0]
[ 0,                             k*(DELTA - 1),                        0,    0]
[ 0,                                         0,                        0,    0]
[ 0,                                         0,                        0,    0]
[-1,                                         0,                        0,    0]
[ 0,                                         0,                        0,    0]
[ 0,                                         0,                      RHO,    0]
[ 0,                                         0,                        0,    0]
[ 0,                                         0,                        0, RHOX]
];
nfxp = [
[ 0,                                                                        0,                                0,  0]
[ 0,                                                                        0,                                0,  0]
[ 0,                                                                        0,                                0,  0]
[ 0,                                                                        0,                                0,  0]
[-1,                                                                        0,                                0,  0]
[ 0, - PHI*k*la - BETTA*la*(PHI*k - (ALFA*a*k*(k/h)^(ALFA - 2)*(ALFA - 1))/h), ALFA*BETTA*a*la*(k/h)^(ALFA - 1),  0]
[-1,                                                                        0,                                0,  0]
[ 0,                                                                        k,                                0,  0]
[ 0,                                                                        0,                                0,  0]
[ 0,                                                                        0,                                0,  0]
[ 1,                                                                        0,                                0,  0]
[ 0,                                                                        0,                                0,  0]
[ 0,                                                                        0,                               -1,  0]
[ 0,                                                                        k,                                0,  0]
[ 0,                                                                        0,                                0, -1]
];
nfy = [
[                                       0,    0,          0,                                                                      0,      -la,  0,        0,  0,        0,  0, 0]
[                                       0,    0,    -output,                                        -(a*h*k^ALFA*(ALFA - 1))/h^ALFA,        0,  0,        0,  0,        0,  0, 0]
[-(SIGG*c)/(c - h^OMEGA/OMEGA)^(SIGG + 1),    0,          0,                  (SIGG*h*h^(OMEGA - 1))/(c - h^OMEGA/OMEGA)^(SIGG + 1),      -la,  0,        0,  0,        0,  0, 0]
[                                       0,    0,          0, (ALFA*a*k*(k/h)^(ALFA - 1)*(ALFA - 1))/h - h*h^(OMEGA - 2)*(OMEGA - 1),        0,  0,        0,  0,        0,  0, 0]
[                                       0,    0,          0,                                                                      0, -BETTA*b,  0,        0,  0,        0,  0, 0]
[                                       0,    0,          0,                                                                      0,      -la,  0,        0,  0,        0,  0, 0]
[                                       0,    0,          0,                                                                      0,        0,  0,        1,  0,        0,  0, 1]
[                                       0, -ivv,          0,                                                                      0,        0,  0,        0,  0,        0,  0, 0]
[                                      -c, -ivv,     output,                                                                      0,        0,  0,       -1,  0,        0,  0, 0]
[                                       0,    0, -tb/output,                                                                      0,        0,  0, 1/output, -1,        0,  0, 0]
[                                       0,    0,          0,                                                                      0,        0,  0,        0,  0,       -1,  0, 0]
[                                       0,    0, -ca/output,                                                                      0,        0,  0,        0,  0, 1/output, -1, 0]
[                                       0,    0,          0,                                                                      0,        0,  0,        0,  0,        0,  0, 0]
[                                       0,    0,          0,                                                                      0,        0, -k,        0,  0,        0,  0, 0]
[                                       0,    0,          0,                                                                      0,        0,  0,        0,  0,        0,  0, 0]
];
nfyp = [
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                        BETTA*b,              0, 0, 0, 0, 0, BETTA]
[0, 0, 0, -(ALFA*BETTA*a*k*la*(k/h)^(ALFA - 2)*(ALFA - 1))/h, BETTA*la*(ALFA*a*(k/h)^(ALFA - 1) - DELTA + 1), BETTA*PHI*k*la, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
[0, 0, 0,                                                  0,                                              0,              0, 0, 0, 0, 0,     0]
];
nf = [
[x - la, a*h^(1 - ALFA)*k^ALFA - output, 1/(c - h^OMEGA/OMEGA)^SIGG - la, - h^(OMEGA - 1) - a*(k/h)^ALFA*(ALFA - 1), BETTA*b - s, BETTA*la*(ALFA*a*(k/h)^(ALFA - 1) - DELTA + 1) - la, b - s + tb, k - ivv + k*(DELTA - 1), output - ivv - c - tb, tb/output - tby, -ca, ca/output - cay, RHO*log(a) - log(a), 0, RHOX*log(x/XSS) - log(x/XSS)]
];
nf=transpose(nf);
nETASHOCK = [
        0
        0
STD_EPS_A
STD_EPS_X
];
nvarshock = [
[0, 0,                         0,                         0]
[0, 0,                         0,                         0]
[0, 0, STD_EPS_A*conj(STD_EPS_A), STD_EPS_A*conj(STD_EPS_X)]
[0, 0, STD_EPS_X*conj(STD_EPS_A), STD_EPS_X*conj(STD_EPS_X)]
];
nvarme = [
];
ns = 1;
nk = 2;
na = 3;
nx = 4;
nstate = 4;
nc = 1;
nivv = 2;
noutput = 3;
nh = 4;
nla = 5;
nkfu = 6;
ntb = 7;
ntby = 8;
nca = 9;
ncay = 10;
nb = 11;
ncontrol = 11;

function dist = cam_calibrate_optimize(x, target_std, target_autocorr)

    rhox = x(1);
    stdx = x(2);

    try
        cam_ss;                  
        RHOX       = rhox;          
        STD_EPS_X  = stdx;

        cam_num_eval;                

        [gx,hx,exitflag] = gx_hx(nfy,nfx,nfyp,nfxp);

        varshock = nETASHOCK*nETASHOCK';

        [sigy0,~] = mom(gx,hx,varshock);          
        [sigy1,~] = mom(gx,hx,varshock,1);       
        noutput = 3;                           
        std_output      = 100*sqrt(sigy0(noutput,noutput));
        autocorr_output =  sigy1(noutput,noutput) / sigy0(noutput,noutput);


        dist = (std_output      - target_std     )^2 + ...
               (autocorr_output - target_autocorr)^2;
    catch                      
        dist = 1e6;             
    end
end
function dist = edeir_calibrate_optimize(x, target_std)

    stdx = x(1);

    try
        edeir_ss;                
        ETATILDE  = stdx;
        edeir_model_num_eval;                

        [gx,hx,exitflag] = gx_hx(nfy,nfx,nfyp,nfxp);

        varshock = nETASHOCK*nETASHOCK';

        [sigy0,~] = mom(gx,hx,varshock);          
        noutput = 3;                           
        std_output      = 100*sqrt(sigy0(noutput,noutput));

        dist = (std_output      - target_std     )^2 ;
    catch                      
        dist = 1e6;             
    end
end